from django.db import models


# class Order(models.Model):
#     orderId = models.BigAutoField(primary_key=True)
#     orderNumber = models.IntegerField()
#     startTime = models.DateTimeField(auto_now=True)
    # endTime = models.DateTimeField()
    # isComplete = models.BooleanField(auto_created=False)
